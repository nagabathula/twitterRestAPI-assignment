from django.urls import path
from . import views

# URL configuration
urlpatterns = [
    path('home/',views.load_home_page, name='home'),
]
