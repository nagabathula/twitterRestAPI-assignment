from django.apps import AppConfig


class TwitterapiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'twitterapi'
